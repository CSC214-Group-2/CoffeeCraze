package com.example.interfacetest;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.event.ActionEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class NewAccountController {


    @FXML
    void printTicket(ActionEvent event) {
       //System.out.println(Seat.seatNumber);
        //System.out.println(ReservationController.booking);

        try {
        FileWriter myWriter = new FileWriter("newCashier.txt");
        myWriter.write("Hello");
        myWriter.close();
        System.out.println("Printed");
    } catch (IOException var3) {
        System.out.println("An error occurred.");
        var3.printStackTrace();
    }

}

    //registers cashier using usr input and password input
    public void cashierReg(String newUsr, String newPass){
        Cashier regCashier = new Cashier(newUsr, newPass);
        // system.add(regCashier);
    }

    @FXML
    private Button Create;




    //Send user back to log-in screen after account creation
    @FXML
    protected void onCreateButtonClick() throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("log_in.fxml"));
        Stage window = (Stage) Create.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 905, 583));
    }
}
