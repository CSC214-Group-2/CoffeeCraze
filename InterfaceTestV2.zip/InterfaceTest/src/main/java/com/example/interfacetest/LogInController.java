package com.example.interfacetest;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import java.io.File;
import java.util.ArrayList;

public class LogInController {

    //FXML Objects
    @FXML
    private Button Continue;            //After username and password is entered
    @FXML
    private Button newAccount;          //Generates new Cashier object

    //Create Cashier object and create .txt associated with it to store data (This will be under "Create New User"
    //on interface (FXML object)

    //This is a test cashier object
    Cashier testCashier = new Cashier("Ken Ding", "01/01/01", "222-222-2222", "email@email.com",
            1111, "KenDing1111", "password");




    //Get cashier username and password from cashier (this will be using an FXML object)


    static ArrayList<Cashier> system = new ArrayList<Cashier>(); //stores people (used for login information)

    //stores input for username and password
    String usrInput;
    String pwInput;

    @FXML
    void userCheck(ActionEvent event) {

        //checks inputted login information (user input and password input)
        //Use strcmp to check if the username and password match. If they match, then proceed to the next
        //scene when Enter button is clicked.

        for (Cashier system : system) {
            if ((system.username.equals(usrInput)) && (system.password.equals (pwInput))) {
                //TO DO
                //EXECUTE CODE THAT LOGS IN OPERATOR AND SENDS THEM TO THE NEXT SCREEN
                System.out.println("AWESOME?!");
            } else {
                //TO DO
                //EXECUTE CODE THAT SENDS OUT AN ERROR: INCOMPATIBLE LOGIN AND PASSWORD
                System.out.println("not cool.");
             }
        }
    }


    //Go to new account screen
    @FXML
    protected void onNewUserClick() throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("new_account.fxml"));
        Stage window = (Stage) newAccount.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 905, 583));
    }

    //Go to main men controller on Continue button click
    @FXML
    protected void onEnterButtonClick() throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("main-menu.fxml"));
        Stage window = (Stage) Continue.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 905, 583));
    }

}