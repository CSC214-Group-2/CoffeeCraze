package com.example.interfacetest;

public class Food extends Item {
    boolean vegetarian; //if true, meal is vegetarian


    //setters and getters
    public boolean getVegetarian(){
        return vegetarian;
    }

    public void setVegetarian(boolean vegetarian){
        this.vegetarian = vegetarian;
    }


    //object constructor
    public Food(double price, String description, int stockQty, boolean cold, boolean vegetarian, int qtySel, boolean selected){
        super(price, description, stockQty, cold, qtySel, selected);

        this.vegetarian = vegetarian;
    }


    /*
    @Override
    public String toString(){
        return "price: "+ price + " desc: " + description + " stock: " + stockQty + "quantity selected: " + qtySel + " item selected: " + selected + " vegetarian?: " + vegetarian +  " cold?:" + cold + "\n";
    }
     */

}
