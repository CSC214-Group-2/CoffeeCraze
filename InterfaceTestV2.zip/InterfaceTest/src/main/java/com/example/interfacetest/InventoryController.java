package com.example.interfacetest;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.File;
import java.util.ArrayList;

public class InventoryController {

    static ArrayList<Item> inventory = new ArrayList<Item>(); //inventory of items, supposed to go into controller


    @FXML
    private Button backToMenu;

}