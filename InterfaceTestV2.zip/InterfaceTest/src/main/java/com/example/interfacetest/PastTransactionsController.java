package com.example.interfacetest;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class PastTransactionsController {

///*

    //is the design going to be a scrollable listview with dates of past transactions and clicking on a
    //date pulls up the past transactions on another listview? if so:

    //list of past transactions, should only show dates on listview
    ArrayList<Item> pastTransactions = new ArrayList();
    @FXML
    private ListView<Item> pTranList; //should be connected to pastTransactions

    //shows entire list of selected transaction
    @FXML
    private ListView<Item> pTranListExpanded;

    //button press pulls up selected transaction on the showcase listview
    @FXML
    public void showTransaction(ActionEvent event){

        Item selectedTransaction = pTranList.getSelectionModel().getSelectedItem();
        pTranListExpanded.getItems().clear();
        pTranListExpanded.getItems().addAll(selectedTransaction);

    }

    /*
    //this should inintialize the past transactions list and load to pastTransactions array list
    //still have to work on outputting transaction list itself into a file
    //try using objectoutputstream or something
    public void initialize(URL url, ResourceBundle resourcebundle) throws IOException, ClassNotFoundException {

        //should load the transactions list then put into the listviews
        FileInputStream fis = new FileInputStream();
        ObjectInputStream ois = new ObjectInputStream(fis);
        ArrayList<Item> loadedTransactions = (ArrayList<Item>) ois.readObject();
        ois.close();
        pastTransactions = loadedTransactions;
        pTranList.getItems().addAll(pastTransactions);


    }
*/

//*/



    //button press action that should return to main menu
    @FXML
    private Button menu;
    //this should switch scenes into past_transactions
    @FXML
    protected void returntoMenu(ActionEvent event) throws Exception{
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("main-menu.fxml"));
        Stage window = (Stage) menu.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 905, 583));

    }

    //button press action that should go to transactions
    @FXML
    private Button transactions;
    //this should switch scenes into past_transactions
    @FXML
    protected void gotoTransactions(ActionEvent event) throws Exception{
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("past_transactions.fxml"));
        Stage window = (Stage) menu.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 905, 583));

    }



}