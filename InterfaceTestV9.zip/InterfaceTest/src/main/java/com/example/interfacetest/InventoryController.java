package com.example.interfacetest;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class InventoryController {

    //Variables to store user input
    String drink;
    String food;

    //FXML objects
    @FXML
    private TextField enterDrink;
    @FXML
    private TextField enterFood;
    @FXML
    private ListView<String> drinkInventoryView;
    @FXML
    private ListView<String> foodInventoryView;
    @FXML
    private Button addDrink;
    @FXML
    private Button addFood;

    //On initialize read the inventory files and display on listview objects
    @FXML
    public void initialize() throws Exception {

        //Read drink inventory list
        File inventoryDrink = new File("/Users/abigailgaunt/IdeaProjects/InterfaceTest/drinkInventory.txt");
        Scanner scanner = new Scanner(inventoryDrink);

        while (scanner.hasNext()) {

            String readInventoryDrink = scanner.nextLine();
            //Separate into String array at ,
            String[] splitList = readInventoryDrink.split(",");

            //Item found at first index is saved as a drink
            drink = splitList[0];

            //Add item to array list
            drinkInventoryView.getItems().add(drink);

        }

        //Read food inventory list
        File inventoryFood = new File("/Users/abigailgaunt/IdeaProjects/InterfaceTest/foodInventory.txt");
        Scanner scanner2 = new Scanner(inventoryFood);

        while (scanner2.hasNext()) {

            String readInventoryFood = scanner2.nextLine();
            //Separate into String array at ,
            String[] splitList = readInventoryFood.split(",");

            //Item found at first index is saved as food
            food = splitList[0];

            //Add item to array list
            foodInventoryView.getItems().add(food);

        }
    }

    //When a drink description is entered, it is saved in the inventory
    @FXML
    public void onEnterDrink() throws Exception {
        try {
            //Write drink to drink inventory file
            drink = enterDrink.getText();
            FileWriter myWriter = new FileWriter("drinkInventory.txt", true);
            myWriter.write(drink + System.lineSeparator());
            enterDrink.clear();
            drinkInventoryView.getItems().add(drink);
            drink = null;
            myWriter.close();

        } catch (IOException var3) {
            System.out.println("Error");
        }
    }

    //When a food description is entered, it is saved in the inventory
    @FXML
    public void onEnterFood() {
        try {
            //Write drink to drink inventory file
            food = enterFood.getText();
            FileWriter myWriter = new FileWriter("foodInventory.txt", true);
            myWriter.write(food + System.lineSeparator());
            enterFood.clear();
            foodInventoryView.getItems().add(food);
            food = null;
            myWriter.close();

        } catch (IOException var3) {
            System.out.println("Error");
        }
    }

    //Return to the main menu on button click
        @FXML
        private Button backToMenu;
        @FXML
        public void onBackToMenuClick () throws Exception {
            FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("main-menu.fxml"));
            Stage window = (Stage) backToMenu.getScene().getWindow();
            window.setScene(new Scene(fxmlLoader.load(), 905, 583));
        }}

