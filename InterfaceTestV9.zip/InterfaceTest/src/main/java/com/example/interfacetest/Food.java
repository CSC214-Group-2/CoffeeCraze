package com.example.interfacetest;

public class Food extends Item {
    private String hereOrGo;
    private String spreadType;


    //setters and getters
    public void setHereOrGo(String hereOrGo){this.hereOrGo = hereOrGo;}
    public String getHereOrGo(){return hereOrGo;}

    public void setSpreadType(String spreadType){this.spreadType = spreadType;}
    public String getSpreadType(){return spreadType;}

    //object constructor
    public Food(){}

    //toString method
    public String toString(){
        return "Item: " + description + "\n\t" + getHereOrGo() + "\n\tSpread: " + getSpreadType() + "\n\t\t\tPrice: $" + getPrice();
    }


}
