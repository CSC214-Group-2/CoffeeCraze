package com.example.interfacetest;

import java.util.ArrayList;

public class Transaction {

    //object variables
    int orderNumber;
    ArrayList<Item> items = new ArrayList<>();
    boolean paymentStatus;
    String paymentType;
    double transactionPrice;

    //object constructor
    public Transaction(){}
    public Transaction(int orderNumber, ArrayList<Item> items, boolean paymentStatus, String paymentType,
                       double transactionPrice){

        this.orderNumber = orderNumber;
        this.items = items;
        this.paymentStatus = paymentStatus;
        this.paymentType = paymentType;
        this.transactionPrice = transactionPrice;

    }

    //setters and getters
    public int getOrderNumber(){return orderNumber;}
    public ArrayList<Item> getItems(){return items;}
    public boolean getpaymentStatus(){return paymentStatus;}
    public String getPaymentType(){return paymentType;}
    public double getTransactionPrice(){return transactionPrice;}

    public void setOrderNumber(int orderNumber){this.orderNumber = orderNumber;}
    public void setItems(ArrayList<Item> items){this.items = items;}
    public void setPaymentStatus(boolean paymentStatus){this.paymentStatus = paymentStatus;}
    public void setPaymentType(String paymentType){this.paymentType = paymentType;}
    public void setTransactionPrice(int transactionPrice){this.transactionPrice = transactionPrice;}

    //toString method to print transaction
    @Override
    public String toString(){
        return "Order Number: " + orderNumber + "Items" + items + "Payment status: " + paymentStatus +
                "Payment type: " + paymentType + "Price: " + transactionPrice;
    }

}
