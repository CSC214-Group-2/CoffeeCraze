package com.example.interfacetest;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.scene.text.Text;
import java.util.Scanner;
import java.io.*;
import java.io.File;
import java.util.ArrayList;
import java.lang.String;
import javafx.scene.control.Button;

public class TransactionController {

    //Text area to display customer order
    @FXML
    private ListView<String> customerOrder;

    //object arraylist for items in cart
    static ArrayList<Item> cart = new ArrayList<>();

    //string arraylists for item names from inventory
    static ArrayList<String> inventoryDrinks = new ArrayList<>();
    static ArrayList<String> inventoryFoods = new ArrayList<>();

    //Drink object to store user selection
    Drink coffee = new Drink();

    //Food Object to store user selection
    Food pastry = new Food();

    //Variables to track order information
    double orderPrice;
    boolean paidOrUnpaid = false;
    int orderNumber;
    String selectedPaymentType;

    //ComboBoxes to allow for user input of drink type, temp, and size
    @FXML
    private ComboBox<String> CoffeeTempList = new ComboBox<>();

    @FXML
    private ComboBox<String> CoffeeTypeList = new ComboBox<>();
    @FXML
    private ComboBox<String> CoffeeSizeList = new ComboBox<>();

    //ComboBoxes to allow for user input of food items
    @FXML
    private ComboBox<String> PastryTypeList = new ComboBox<>();
    @FXML
    private ComboBox<String> PastryHereOrGoList = new ComboBox<>();
    @FXML
    private ComboBox<String> PastrySpreadList = new ComboBox<>();
    @FXML
    private ComboBox<String> PaymentTypeList = new ComboBox<>();

    //Initialize ComboBox contents based on current inventory
    @FXML
    protected void initialize() throws Exception {

        //Read drink inventory file
        File inventoryData = new File("drinkInventory.txt");
        Scanner scanner = new Scanner(inventoryData);

        while (scanner.hasNext()) {

            //Create string object to temporarily store data
            String newDrink = new String();

            //read file with the scanner
            String readInventoryData = scanner.nextLine();

            //Separate into String array at ,
            String[] splitList = readInventoryData.split(",");

            //Item found at first index is saved as a drink
            newDrink = splitList[0];

            //Add item to array list
            inventoryDrinks.add(newDrink);

            //Add item to ComboBox on interface
            CoffeeTypeList.getItems().add(newDrink);

        }

        //Read food inventory file
        File inventoryData2 = new File("foodInventory.txt");
        Scanner scanner2 = new Scanner(inventoryData2);

        while (scanner2.hasNext()) {

            //Create string object to temporarily store data
            String newFood = new String();

            //Read file with the scanner
            String readInventoryData2 = scanner2.nextLine();

            //Separate into String array at ,
            String[] splitList2 = readInventoryData2.split(",");

            //Item found at first index is saved as food
            newFood = splitList2[0];

            //Add item to array list
            inventoryFoods.add(newFood);

            //Add item to ComboBox on interface
            PastryTypeList.getItems().add(newFood);
        }

        //Set base price for coffee and pastry
        coffee.setPrice(3.0);
        pastry.setPrice(3.5);

        //Drop down menu items that won't be changeable in inventory
        CoffeeTempList.getItems().add("Hot");
        CoffeeTempList.getItems().add("Iced");

        CoffeeSizeList.getItems().add("Small");
        CoffeeSizeList.getItems().add("Medium");
        CoffeeSizeList.getItems().add("Large");

        PastryHereOrGoList.getItems().add("Here");
        PastryHereOrGoList.getItems().add("To-Go");
        PastrySpreadList.getItems().add("Butter");
        PastrySpreadList.getItems().add("Cream Cheese");
        PastrySpreadList.getItems().add("Chocolate Spread");
        PastrySpreadList.getItems().add("None");

        PaymentTypeList.getItems().add("Credit Card");
        PaymentTypeList.getItems().add("Cash");
        PaymentTypeList.getItems().add("Check");
    }

    //Controls selection of coffee type
    @FXML
    public void onTypeSelect() {
        for (String inventoryDrink : inventoryDrinks) {

            if (CoffeeTypeList.getValue().equals(inventoryDrink)) {

                coffee.setDescription(inventoryDrink);
            }
        }
    }

    //Controls selection of coffee temp
    @FXML
    public void onTempSelect() {

        if (CoffeeTempList.getValue().equals("Iced")) {
            coffee.setTemp("Iced");
        } else {
            coffee.setTemp("Hot");
        }
    }

    //Controls selection of coffee size and price variation
    @FXML
    public void onSizeSelect() {
        if (CoffeeSizeList.getValue().equals("Small")) {
            coffee.setSize(1);
        } else if (CoffeeSizeList.getValue().equals("Medium")) {
            coffee.setSize(2);
            coffee.setPrice(3.3);
        } else {
            coffee.setSize(3);
            coffee.setPrice(3.6);
        }
    }

    //Controls selection of pastry type
    @FXML
    public void onPastryTypeSelect() {
        for (String inventoryFood : inventoryFoods) {

            if (PastryTypeList.getValue().equals(inventoryFood)) {

                pastry.setDescription(inventoryFood);
            }
        }
    }

    //Controls selection of pastry for here or to-go
    @FXML
    public void onPastryHereOrGoSelect() {
        if (PastryHereOrGoList.getValue().equals("Here")) {
            pastry.setHereOrGo("Here");
        }
        else {
            pastry.setHereOrGo("To-Go");
        }
    }

    //Controls selection of pastry spread
    @FXML
    public void onPastrySpreadSelect() {
        if (PastrySpreadList.getValue().equals("Butter")) {
            pastry.setSpreadType("Butter");
        } else if (PastrySpreadList.getValue().equals("Cream Cheese")) {
            pastry.setSpreadType("Cream Cheese");
        } else if (PastrySpreadList.getValue().equals("Chocolate Spread")) {
            pastry.setSpreadType("Chocolate Spread");
        } else {
            pastry.setSpreadType("None");
        }
    }

    //Add selected drink or food to cart array list and add to total
    @FXML
    private Button addToOrder;
    @FXML
    private Button addToOrder2;
    @FXML
    public void addToOrderClick() {
        cart.add(coffee);
        customerOrder.getItems().add(coffee.toString());
        orderPrice += coffee.getPrice();
    }

    @FXML public void AddToOrder2Click() {
        cart.add(pastry);
        customerOrder.getItems().add(pastry.toString());
        orderPrice += pastry.getPrice();
    }

    //To complete the order and display the price
    @FXML
    private Button completeOrder;
    @FXML
    private Text total;
    @FXML
    public void onCompleteOrderClick() {

        total.setText(String.valueOf(orderPrice));
    }

    //Control ComboBox to select customer payment type
    @FXML
    public void onPaymentTypeSelect() {
        if (PaymentTypeList.getValue().equals("Credit Card")) {
            selectedPaymentType = "Credit Card";
        } else if (PaymentTypeList.getValue().equals("Cash")) {
            selectedPaymentType = "Cash";
        } else if (PaymentTypeList.getValue().equals("Check")){
            selectedPaymentType = "Check";
        } else
        {
            selectedPaymentType = "Not Selected";
        }
    }

    @FXML
    private TextField customerPayment;
    @FXML
    private Text paymentStatus;
    @FXML
    public void onPaymentEntered() {
        Double paymentEntered = Double.valueOf(customerPayment.getText());
        if (paymentEntered == orderPrice) {
            paidOrUnpaid = true;
            paymentStatus.setText("Paid");
            orderNumber = (int)(Math.random() * 1000);
        }
        else {
            paymentStatus.setText("Incorrect Amount");
        }
    }

    //Write the transaction information to a file
    @FXML
    private Button completeTransaction;
    @FXML
    private Text transactionPassFail;
    @FXML
    public void onCompleteTransactionClick() {
        try {
            FileWriter myWriter = new FileWriter("receipt.txt");
            myWriter.write("Order Number: " + orderNumber + "\n");
            for (Item cart : cart) {
                myWriter.write(cart + System.lineSeparator());
            }
            myWriter.write( "Paid Status: " + paidOrUnpaid + " Payment Type: "
                    + selectedPaymentType + "\n");
            myWriter.close();

            //just testing something with inputoutput object streams real quick
            Transaction transaction = new Transaction(orderNumber, cart, paidOrUnpaid,
                    selectedPaymentType, orderPrice);
            FileOutputStream fos = new FileOutputStream("pastTransactions");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(transaction);
            oos.close();
            System.out.println("Saved to pastTransaction");

            transactionPassFail.setText("Ticket Printed.");
        } catch (IOException var3) {
            transactionPassFail.setText("Unable to complete transaction");
            var3.printStackTrace();
        }

    }

    //Clear the entire order from cart and order screen
    @FXML
    private Button clearOrder;
    @FXML
    public void onClearOrderClick() {
        customerOrder.getItems().clear();
        cart.clear();
        orderPrice = 0;
    }

    @FXML
    private Button removeItem;

    //Remove a selected item from order screen
    // action event
/*
    @FXML
    public void onItemRemovalSelect() {

                customerOrder.getSelectionModel().selectedItemProperty().addListener((observableValue, s, t1) -> {
                    {
                        for (Integer i : customerOrder.getSelectionModel().getSelectedIndices()) {
                            Item item = cart.get(i);
                            removeItem.setOnAction(e -> {
                                cart.remove(item);
                                customerOrder.getItems().remove(item.toString());
                            });
                        }
                    }
                });
            }

*/

    //Back Button
    @FXML
    private Button backToMenu;

    @FXML
    protected void onBackToMenuClick() throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("main-menu.fxml"));
        Stage window = (Stage) backToMenu.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 905, 583));
    }

}
