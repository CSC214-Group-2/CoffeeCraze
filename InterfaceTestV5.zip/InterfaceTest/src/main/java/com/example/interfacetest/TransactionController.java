package com.example.interfacetest;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.scene.text.Text;
import java.io.File;
import java.io.IOException;
import java.io.File;
import java.util.ArrayList;

public class TransactionController {

    //FXML Objects
    @FXML
    private ListView<String> CoffeeTypeList;
    @FXML
    private ListView<String> CoffeeTempList;
    @FXML
    private ListView<String> CoffeeSizeList;
    @FXML
    private TextArea customerOrder;

    @FXML
    protected void initialize() {

        //Temporary initialize for menu listview
        CoffeeTypeList.getItems().add("Regular");
        CoffeeTypeList.getItems().add("Decaf");
        CoffeeTempList.getItems().add("Hot");
        CoffeeTempList.getItems().add("Iced");
        CoffeeSizeList.getItems().add("Small");
        CoffeeSizeList.getItems().add("Medium");
        CoffeeSizeList.getItems().add("Large");
    }

    @FXML public void onItemSelect(MouseEvent arg0) {
        Drink coffee = new Drink();
         String userInput = CoffeeTempList.getSelectionModel().getSelectedItem();
         if (userInput.equals("Iced")){
             coffee.setCold(true);
         }
    }

        /*

        CoffeeTypeList.getSelectionModel().selectedItemProperty().addListener((observableValue, s, t1) -> {
                    {
                        for (Integer i: CoffeeTypeList.getSelectionModel().getSelectedIndices()) {

                            CoffeeTypeList.getSelectionModel().select(i);
                    }
                }
    }

         */
    //CoffeeList.remove("Regular");

    /*

    //adds transaction to receipt and prints receipt?
    public void saveTransaction(ActionEvent event){


    }
        //@FXML ;BUTTON CREATES FILE
    //void printTicket(ActionEvent event) {
        System.out.println(Seat.seatNumber);
        System.out.println(ReservationController.booking);

        try {
            FileWriter myWriter = new FileWriter("receipt.txt");
                myWriter.write("Your Receipt:\n" + LogInController.name + ",\n: " + LogInController.dob);
            myWriter.close();
            this.viewInfo.setText("Ticket Printed.");
        } catch (IOException var3) {
            System.out.println("An error occurred.");
            var3.printStackTrace();
        }

    }

    public void printTransaction(ActionEvent event){


    }

    @FXML
    private Button switchPTran;
    //this should switch scenes into past_transactions
    @FXML
    protected void accessPastTransactions(ActionEvent event) throws Exception{
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("past_transactions.fxml"));
        Stage window = (Stage) switchPTran.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 905, 583));

    }

    //this is a test food object
    Item testFood = new Food(2, "awesome", 4, false, true, 4, false);

    //object arraylist for items in cart
    static ArrayList<Item> cart = new ArrayList<Item>();

    //adds up the items, returns sum for transaction
    public int transSum(){
        int sum = 0;
        for (Item cart : cart){
            sum += cart.price;
        }
        return sum;
    }

    //receipt generation
    public String[] receiptGen(){
        
        String[] cartText = {};

        for (Item cart : cart){
            int i = 0;
            cartText[i] = cart.toString();
            i++;
        }
        return cartText;
    }



    @FXML
    private Button backToMenu;

    @FXML
    protected void onBackToMenuClick() throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("main-menu.fxml"));
        Stage window = (Stage) backToMenu.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 905, 583));
    }


*/
}