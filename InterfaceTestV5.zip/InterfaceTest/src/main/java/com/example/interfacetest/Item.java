package com.example.interfacetest;

public class Item{

    double price; //price of product
    String description; // description of the product
    int stockQty, qtySel; //quantity of product in stock, quantity selected
    boolean selected, cold; //if item is selected, if item is a cold item

    //object constructor
    public Item(){}
    public Item(double price, String description, int stockQty, boolean cold, int qtySel, boolean selected){
        this.price = price;
        this.description = description;
        this.stockQty = stockQty;
        this.cold = cold;
        this.qtySel = qtySel;
        this.selected = selected;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }


    public void setDescription(String description) {
        this.description = description;
    }

    public int getStockQty() {
        return stockQty;
    }

    public void setStockQty(int quantity) {
        this.stockQty = quantity;
    }

    public int getQtySel() {
        return qtySel;
    }

    public void setQtySel(int quantity) {
        this.qtySel = qtySel;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public void setCold(boolean cold) {
        this.cold = cold;
    }

    //@Override
    //public String toString(){
    //    return "price: "+ price + " desc: " + description + " stock: " + stockQty + "quantity selected: " + qtySel + " item selected: " + selected + " cold: " + cold;
    //}

    //toString method used for the receipt
    @Override
    public String toString(){
        return "Price: $"+ price + "\n   Description:" + description + "\n   Qty: " + qtySel;
    }



}
