/*
 * Group 2
 * Coffee Shop Menu Project.
 * Abigail Gaunt
 * Max Mazal
 * Kevin Ung
 * Jared Rigor
 * Rouhid Ayazi
 *
 * October 20, 2022: Started Project
 * Class: CSC 214 - 401
 * Description: Basic Interface for our menu.
 *
      )  (
     (   ) )
      ) ( (
    _______)_
 .-'---------|
( C|/\/\/\/\/|
 '-./\/\/\/\/|
   '_________'
    '-------'
 */

package com.example.interfacetest;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.util.ArrayList;

import java.io.IOException;

public class FinalProject extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("log-in.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 350, 240);
        stage.setTitle("Coffee Craze");
        stage.setScene(scene);
        stage.show();
    }

    //Main Function
    public static void main(String[] args) {

        launch();
    }

    //arraylist for objects in cart, this will be moved to correct controller

    //UI, will use all variables
    //transaction / receipt, will only need qty selected, name, and price
    //array list for cashier users







}




