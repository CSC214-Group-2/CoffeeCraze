package com.example.interfacetest;

public class People {

    //variables
    String name;    //Name
    String dob;     //Date of birth
    String phoneNumber; //Phone Number
    String email;       //Email

    //object constructor
    public People(String name, String dob, String phoneNumber, String email){
        this.name = name;
        this.dob = dob;
        this.phoneNumber = phoneNumber;
        this.email = email;
    }

    //no args constructor
    public People() {

    }

    public String getName(){
        return name;
    }

    public String getDob(){
        return dob;
    }

    public String getPhoneNumber(){
        return phoneNumber;
    }
    public String getEmail(){
        return email;
    }

    public void setPrntrName(String name) {
        this.name = name;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString(){
        return "name: " + name + " dob: " + dob + " phoneNumber: " + phoneNumber + " email: " + email;
    }

}
