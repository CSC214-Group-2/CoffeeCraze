package com.example.interfacetest;

public class Cashier extends People {

    //variable
    //arraylist of Items to rep past transactions
    Item pastTransactions[];
    //string of date the account was last accessed
    String dateLastAccessed;
    //username and password
    String username, password;


    //setters and getters

    public Item[] getItem(){
        return pastTransactions;
    }

    public String getDateLastAccessed(){
        return dateLastAccessed;
    }

    public String getUsername(){
        return username;
    }

    public String getPassword(){
        return password;
    }

    public void setPastTransactions(Item pastTransactions[]){
        this.pastTransactions = pastTransactions;
    }

    public void setDateLastAccessed(String dateLastAccessed){
        this.dateLastAccessed = dateLastAccessed;
    }

    public void setPassword(String password){
        this.password = password;
    }

    public void setUsername(String username){
        this.username = username;
    }
    public String getUsername(String username){
        return username;
    }


    //object constructor
    public Cashier(String name, String dob, String phoneNumber, String email,String username, String password){

        this.name = name;
        this.dob = dob;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.password = password;
        this.username = username;

    }

    //constructor used for registering a new account
    public Cashier(String username, String password){

        this.password = password;
        this.username = username;

    }

    //override
    @Override
    public String toString(){

        return "Name: " + name + "\nDate of Birth: " + dob + "\nPhone Number" + phoneNumber +
                "\nEmail: " + email + "\nAddress: " + "\nPast Transactions: " + pastTransactions + "\nDate Last Accessed: " + dateLastAccessed +
                "\nUsername: " + username +"\nPassword: " + password;

    }

}
