package com.example.interfacetest;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

public class InventoryController {

    static ArrayList<Item> inventory = new ArrayList<Item>(); //inventory of items, supposed to go into controller


    //Variables
    String name;


    @FXML
    private TextField nameTextField;



    private static void saveTofile(String fileName, String text, boolean append) throws IOException {
        //creates file
        File file1 = new File(fileName);

        //creates file writer class
        FileWriter fw = new FileWriter(file1,append);

        //creates a print writer class
        PrintWriter pw = new PrintWriter(fw);

        pw.println(text);

        pw.close();
    }


    @FXML
    protected void onCreateButtonClick() throws Exception {

        //Get the new account information from the user and save it into variables
        //price = priceTextField.getText();
        name = nameTextField.getText();



        //Generate ID Number using math.random()

        //Generate a new file and save the new account information and save to the file

        String outputText = name + "|";

        saveTofile("Inventory2.txt", outputText,true);


        /*
        //Return to the log-in screen
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("log_in.fxml"));
        Stage window = (Stage) Create.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 905, 583));

         */
    }


    @FXML
    private Button backToMenu;

}