package com.example.interfacetest;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class LogInController {

    //This is a test cashier object
    Cashier testCashier = new Cashier("Ken Ding", "01/01/01", "222-222-2222", "email@email.com", "KenDing1111", "password");


    //Get cashier username and password from cashier (this will be using an FXML object)

    static ArrayList<Cashier> system = new ArrayList<Cashier>(); //stores people (used for login information)


    //stores input for username and password from text fields
    String usrInput;
    String pwInput;

    @FXML
    private Button Continue;                    //Initiates username and password check
    @FXML
    private TextField userNameTextField;        //User types already created username
    @FXML
    private TextField passwordTextField;        //User types already created password

    @FXML
    private Text loginIncorrect;                //Displays when username/password is incorrect

    @FXML
    protected void onContinueButtonClick() throws Exception {

        //Get user input and store in string variables
        usrInput = userNameTextField.getText();
        pwInput = passwordTextField.getText();
        system.add(testCashier);

        //Loop through the array list to check for username/password matches
        for (Cashier system : system) {

            //If the username and password match
            if ((system.username.equals(usrInput)) && (system.password.equals(pwInput))) {

                //Then proceed to main menu scene
                FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("main-menu.fxml"));
                Stage window = (Stage) Continue.getScene().getWindow();
                window.setScene(new Scene(fxmlLoader.load(), 905, 583));

            //If username/password is incorrect
            } else {

                //Set text to show user that incorrect info was entered
                loginIncorrect.setText("Username or Password are incorrect");
            }
        }
    }

    //Go to new account screen when New User button is clicked
    @FXML
    private Button newAccount;

    @FXML
    protected void onNewUserClick() throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("new_account.fxml"));
        Stage window = (Stage) newAccount.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 625, 375));
    }

    private static void addFromFile(){
        String newUserName, newPassword, name, dob, phoneNumber, email;

        File inventoryData = new File("systemLog.txt");
        Scanner scanner = null;
        try {
            scanner = new Scanner(inventoryData);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        while(scanner.hasNextLine()){
            String readSystem = scanner.nextLine();
            String[] splitList = readSystem.split("\\|");
            newUserName = splitList[0];
            newPassword = splitList[1];
            name = splitList[2];
            dob = splitList[3];
            phoneNumber = splitList[4];
            email = splitList[5];
            Cashier test = new Cashier(newUserName, newPassword, name, dob, phoneNumber, email);
            System.out.println(test.toString());
        }
    }
}


