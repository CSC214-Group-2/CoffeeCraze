package com.example.interfacetest;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.CheckBox;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.scene.text.Text;
import java.util.Scanner;
import java.io.*;
import java.io.File;
import java.util.ArrayList;
import java.lang.String;
import javafx.event.ActionEvent;

public class TransactionController {

    //Text area to display customer order
    @FXML
    private ListView<String> customerOrder;

    //object arraylist for items in cart
    static ArrayList<Item> cart = new ArrayList<>();

    //string arraylists for item names from inventory
    static ArrayList<String> inventoryDrinks = new ArrayList<>();
    static ArrayList<String> inventoryFoods = new ArrayList<>();

    //Drink object to store user selection
    Drink coffee = new Drink();

    //Food Object to store user selection
    Food pastry = new Food();

    //Variables to track order information
    double orderPrice;
    boolean paidOrUnpaid = false;
    int orderNumber;
    String selectedPaymentType;

    //ComboBoxes to allow for user input of drink type, temp, and size
    @FXML
    private ComboBox<String> CoffeeTempList = new ComboBox<>();

    @FXML
    private ComboBox<String> CoffeeTypeList = new ComboBox<>();
    @FXML
    private ComboBox<String> CoffeeSizeList = new ComboBox<>();

    //ComboBoxes to allow for user input of food items
    @FXML
    private ComboBox<String> PastryTypeList = new ComboBox<>();
    @FXML
    private ComboBox<String> PastryHereOrGoList = new ComboBox<>();
    @FXML
    private ComboBox<String> PastrySpreadList = new ComboBox<>();
    @FXML
    private ComboBox<String> PaymentTypeList = new ComboBox<>();

    //Initialize ComboBox contents based on current inventory
    //This is where we will have it read from the inventory file, parse the information,
    //and have it fill in the menu selection
    @FXML
    protected void initialize() throws Exception {

        //Change item names in inventory
        File inventoryData = new File("/Users/abigailgaunt/Desktop/Inventory.txt");
        Scanner scanner = new Scanner(inventoryData);

        while (scanner.hasNext()) {

            //Create string object and add to ArrayList
            String newDrink = new String();

            //read file with the scanner
            String readInventoryData = scanner.nextLine();

            //Separate into String array at ,
            String[] splitList = readInventoryData.split(",");

            //Item found at first index is saved as a drink
            newDrink = splitList[0];

            //Add item to array list
            inventoryDrinks.add(newDrink);

            //Add item to ComboBox on interface
            CoffeeTypeList.getItems().add(newDrink);

            /*
            CoffeeTypeList.getItems().add("Regular Coffee");
            CoffeeTypeList.getItems().add("Decaf Coffee");
            CoffeeTypeList.getItems().add("Mocha");
            CoffeeTypeList.getItems().add("Cappuccino");
            CoffeeTypeList.getItems().add("Latte");


            PastryTypeList.getItems().add("Bagel");
            PastryTypeList.getItems().add("Croissant");
            PastryTypeList.getItems().add("Sticky Bun");
            PastryTypeList.getItems().add("Danish");

             */
        }

        //Drop down menu items that won't be changeable in inventory
        CoffeeTempList.getItems().add("Hot");
        CoffeeTempList.getItems().add("Iced");

        CoffeeSizeList.getItems().add("Small");
        CoffeeSizeList.getItems().add("Medium");
        CoffeeSizeList.getItems().add("Large");

        PastryHereOrGoList.getItems().add("Here");
        PastryHereOrGoList.getItems().add("To-Go");
        PastrySpreadList.getItems().add("Butter");
        PastrySpreadList.getItems().add("Cream Cheese");
        PastrySpreadList.getItems().add("Chocolate Spread");
        PastrySpreadList.getItems().add("None");

        PaymentTypeList.getItems().add("Credit Card");
        PaymentTypeList.getItems().add("Cash");
        PaymentTypeList.getItems().add("Check");
    }

    //Controls selection of coffee type
    @FXML
    public void onTypeSelect() {
        for (String inventoryDrink : inventoryDrinks) {

            if (CoffeeTypeList.getValue().equals(inventoryDrink)) {

                coffee.setDescription(inventoryDrink);
            }
        }
    }

    //Controls selection of coffee temp
    @FXML
    public void onTempSelect() {

        if (CoffeeTempList.getValue().equals("Iced")) {
            coffee.setTemp("Iced");
        } else {
            coffee.setTemp("Hot");
        }
    }

    //Controls selection of coffee size
    @FXML
    public void onSizeSelect() {
        if (CoffeeSizeList.getValue().equals("Small")) {
            coffee.setSize(1);
            coffee.setPrice(2.0);
        } else if (CoffeeSizeList.getValue().equals("Medium")) {
            coffee.setSize(2);
            coffee.setPrice(2.3);
        } else {
            coffee.setSize(3);
            coffee.setPrice(2.6);
        }
    }

    //Controls selection of pastry type
    @FXML
    public void onPastryTypeSelect() {
        if (PastryTypeList.getValue().equals("Bagel")) {
            pastry.setDescription("Bagel");
        } else if (PastryTypeList.getValue().equals("Croissant")) {
            pastry.setDescription("Croissant");
        } else if (PastryTypeList.getValue().equals("Sticky Bun")) {
            pastry.setDescription("Sticky Bun");
        } else {
            pastry.setDescription("Danish");
        }
    }

    //Controls selection of pastry for here or to-go
    @FXML
    public void onPastryHereOrGoSelect() {
        if (PastryHereOrGoList.getValue().equals("Here")) {
            pastry.setHereOrGo("Here");
        }
        else {
            pastry.setHereOrGo("To-Go");
        }
    }

    //Controls selection of pastry spread
    @FXML
    public void onPastrySpreadSelect() {
        if (PastrySpreadList.getValue().equals("Butter")) {
            pastry.setSpreadType("Butter");
        } else if (PastrySpreadList.getValue().equals("Cream Cheese")) {
            pastry.setSpreadType("Cream Cheese");
        } else if (PastrySpreadList.getValue().equals("Chocolate Spread")) {
            pastry.setSpreadType("Chocolate Spread");
        } else {
            pastry.setSpreadType("None");
        }
    }

    //Add selected drink or food to cart array list
    @FXML
    private Button addToOrder;
    @FXML
    private Button addToOrder2;
    @FXML
    public void addToOrderClick() {
        cart.add(coffee);
        customerOrder.getItems().add(coffee.toString());
    }

    @FXML public void AddToOrder2Click() {
        cart.add(pastry);
        customerOrder.getItems().add(pastry.toString());
    }

    //To complete the order and total the price
    @FXML
    private Button completeOrder;
    @FXML
    private Text total;
    @FXML
    public void onCompleteOrderClick() {
        for (Item cart : cart){
            orderPrice += cart.price;
        }
        total.setText(String.valueOf(orderPrice));
    }

    //Control ComboBox to select customer payment type
    @FXML
    public void onPaymentTypeSelect() {
        if (PaymentTypeList.getValue().equals("Credit Card")) {
            selectedPaymentType = "Credit Card";
        } else if (PaymentTypeList.getValue().equals("Cash")) {
            selectedPaymentType = "Cash";
        } else if (PaymentTypeList.getValue().equals("Check")){
            selectedPaymentType = "Check";
        } else
        {
            selectedPaymentType = "Not Selected";
        }
    }

    @FXML
    private TextField customerPayment;
    @FXML
    private Text paymentStatus;
    @FXML
    public void onPaymentEntered() {
        Double paymentEntered = Double.valueOf(customerPayment.getText());
        if (paymentEntered == orderPrice) {
            paidOrUnpaid = true;
            paymentStatus.setText("Paid");
            orderNumber = (int)(Math.random() * 1000);
        }
        else {
            paymentStatus.setText("Incorrect Amount");
        }
    }

    //Write the transaction information to a file
    @FXML
    private Button completeTransaction;
    @FXML
    private Text transactionPassFail;
    @FXML
    public void onCompleteTransactionClick() throws Exception {
        try {
            FileWriter myWriter = new FileWriter("receipt.txt");
            myWriter.write("Order Number: " + orderNumber + "\n");
            for (Item cart : cart) {
                myWriter.write(cart + System.lineSeparator());
            }
            myWriter.write( "Paid Status: " + paidOrUnpaid + " Payment Type: "
                    + selectedPaymentType + "\n");
            myWriter.close();

            //just testing something with inputoutput object streams real quick
            FileOutputStream fos = new FileOutputStream("pastTransactions");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(cart);
            oos.close();
            System.out.println("Saved to ptransaction");

            transactionPassFail.setText("Ticket Printed.");
        } catch (IOException var3) {
            transactionPassFail.setText("Unable to complete transaction");
            var3.printStackTrace();
        }

    }

/*
    @FXML
    private Button removeItem;

    //Remove an item from order screen
    @FXML
    public void onItemRemovalSelect() {
        customerOrder.getSelectionModel().selectedItemProperty().addListener((observableValue, s, t1) -> {
            {
                for (Integer i : customerOrder.getSelectionModel().getSelectedIndices()) {

                    Item item = cart.get(i);
                    cart.remove(item);
                    customerOrder.getItems().remove(item);
                }
            }
        });
    }
*/

    //Back Button
    @FXML
    private Button backToMenu;

    @FXML
    protected void onBackToMenuClick() throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("main-menu.fxml"));
        Stage window = (Stage) backToMenu.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 905, 583));
    }




    //CoffeeList.remove("Regular");

    /*

    //adds transaction to receipt and prints receipt?
    public void saveTransaction(ActionEvent event){


    }
        //@FXML ;BUTTON CREATES FILE
    //void printTicket(ActionEvent event) {
        System.out.println(Seat.seatNumber);
        System.out.println(ReservationController.booking);

        try {
            FileWriter myWriter = new FileWriter("receipt.txt");
                myWriter.write("Your Receipt:\n" + LogInController.name + ",\n: " + LogInController.dob);
            myWriter.close();
            this.viewInfo.setText("Ticket Printed.");
        } catch (IOException var3) {
            System.out.println("An error occurred.");
            var3.printStackTrace();
        }

    }

    public void printTransaction(ActionEvent event){


    }

    @FXML
    private Button switchPTran;
    //this should switch scenes into past_transactions
    @FXML
    protected void accessPastTransactions(ActionEvent event) throws Exception{
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("past_transactions.fxml"));
        Stage window = (Stage) switchPTran.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 905, 583));

    }

    //this is a test food object
    Item testFood = new Food(2, "awesome", 4, false, true, 4, false);

    /

    //adds up the items, returns sum for transaction
    public int transSum(){
        int sum = 0;
        for (Item cart : cart){
            sum += cart.price;
        }
        return sum;
    }

    //receipt generation
    public String[] receiptGen(){
        
        String[] cartText = {};

        for (Item cart : cart){
            int i = 0;
            cartText[i] = cart.toString();
            i++;
        }
        return cartText;
    }


*/
    }
