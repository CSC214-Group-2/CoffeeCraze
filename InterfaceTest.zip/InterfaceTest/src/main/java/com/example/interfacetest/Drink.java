package com.example.interfacetest;

public class Drink extends Item {

    //variables
    boolean cold, ice; //is drink hot or cold? is there ice?
    int size; //0 small, 1 medium, 2 large

    //setters and getters
    public boolean getCold(){
        return cold;
    }

    public boolean ice(){
        return ice;
    }

    public int size(){
        return size;
    }

    public void setCold(boolean cold){
        this.cold = cold;
    }

    public void setIce(boolean ice){
        this.ice = ice;
    }

    public void setSize(int size){
        this.size = size;
    }

    //object constructor
    public Drink(double price, String description, int stockQty, boolean cold, int qtySel, boolean selected, boolean ice, int size){
        super(price, description, stockQty, cold, qtySel, selected);

        this.cold = cold;
        this.ice = ice;
        this.size = size;
    }

    @Override
    public String toString(){
        return "price: "+ price + " desc: " + description + " stock: " + stockQty + "quantity selected: " + qtySel + " item selected: " + selected + " cold:" + cold + " ice:" + ice + " size:" + size;
        }
    }
