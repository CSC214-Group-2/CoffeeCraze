package com.example.interfacetest;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import java.io.File;

public class LogInController {

    //FXML Objects
    @FXML
    private Button Continue;            //After username and password is entered
    @FXML
    private Button newAccount;          //Generates new Cashier object

    //Create Cashier object and create .txt associated with it to store data (This will be under "Create New User"
    //on interface (FXML object)

    //This is a test cashier object
    Cashier testCashier = new Cashier("Ken Ding", "01/01/01", "222-222-2222", "email@email.com",
            1111, "password");

    //This is the test cashier .txt file
    File testCashierFile = new File("testCashierFile.txt");


    //Get cashier username and password from cashier (this will be using an FXML object)



    //Use strcmp to check if the username and password match. If they match, then proceed to the next
    //scene when Enter button is clicked.



    //Go to main men controller on Continue button click
    @FXML
    protected void onEnterButtonClick() throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("main-menu.fxml"));
        Stage window = (Stage) Continue.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 905, 583));
    }

}