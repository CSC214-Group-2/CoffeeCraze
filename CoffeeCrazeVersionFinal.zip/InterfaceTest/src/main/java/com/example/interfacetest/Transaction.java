/**
 * This class represents a transaction
 * @author Group 2
 * @author Jared Rigor
 */
package com.example.interfacetest;

public class Transaction {

    /**
     * orderNumber int variable
     * stores the order number
     */
    int orderNumber;

    /**
     * items String variable
     * stores the string of the items in the order
     */
    String items;

    /**
     * paymentStatus String variable
     * stores whether the customer has paid or not
     */
    String paymentStatus;

    /**
     * paymentType String variable
     * stores the type of payment used
     */
    String paymentType;

    /**
     * transactionPrice double variable
     * stores the transaction total
     */
    double transactionPrice;

    /**
     * Transaction constructor with no parameters
     */
    public Transaction(){}

    /**
     * orderNumber getter method
     * @return int orderNumber
     */
    public int getOrderNumber(){return orderNumber;}

    /**
     * items getter method
     * @return String items
     */
    public String getItems(){return items;}

    /**
     * paymentStatus getter method
     * @return String paymentStatus
     */
    public String getPaymentStatus(){return paymentStatus;}

    /**
     * paymentType getter method
     * @return String paymentType
     */
    public String getPaymentType(){return paymentType;}

    /**
     * transactionPrice getter method
     * @return double transactionPrice
     */
    public double getTransactionPrice(){return transactionPrice;}

    /**
     * orderNumber setter method
     * @param orderNumber int
     */
    public void setOrderNumber(int orderNumber){this.orderNumber = orderNumber;}

    /**
     * items setter method
     * @param items String
     */
    public void setItems(String items){this.items = items;}

    /**
     * paymentStatus setter method
     * @param paymentStatus String
     * Changes true or false to "Paid" or "unpaid"
     */
    public void setPaymentStatus(String paymentStatus){
        if (paymentStatus.equals("true ")) {
            this.paymentStatus = "Paid";
        }
        else {
            this.paymentStatus = "Unpaid";
        }
    }

    /**
     * paymentType setter method
     * @param paymentType String
     */
    public void setPaymentType(String paymentType){this.paymentType = paymentType;}

    /**
     * transactionPrice setter method
     * @param transactionPrice double
     */
    public void setTransactionPrice(double transactionPrice){this.transactionPrice = transactionPrice;}

    /**
     * toString method to display data elements of Transaction
     * @return String of orderNumber, items, paymentStatus, paymentType, transactionPrice
     */
    @Override
    public String toString(){
        return "Order Number: " + orderNumber + "\n" + items + "\nPayment Status: " + paymentStatus +
                "\nPayment type: " + paymentType + "\nPrice: " + transactionPrice;
    }
}
