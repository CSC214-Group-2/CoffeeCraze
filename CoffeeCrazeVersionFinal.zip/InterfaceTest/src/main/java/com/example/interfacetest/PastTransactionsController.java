/**
 * This class controls the Past Transactions scene
 * @author Group 2
 * @author Jared Rigor
 * @author Abigail Gaunt
 */
package com.example.interfacetest;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class PastTransactionsController {

    /**
     * ArrayList to store transaction objects parsed from file
     */
    ArrayList<Transaction> pastTransactions = new ArrayList<>();

    /**
     * FXML ListView to display
     */
    @FXML
    private ListView<Integer> pTranList;

    /**
     * FXML Text to display details of transaction when ListView is clicked
     */
    @FXML
    private Text transactionsDisplayed;

    /**
     * Void Parse File Data Method
     * Reads past transactions from receipt file and saves them into transaction objects
     * @throws Exception file not found
     */
    public void parseFileData() throws Exception {

        File receiptData = new File("receipt.txt");

        checkForFile(receiptData);

        Scanner scanner = new Scanner(receiptData);

        //Loop through file
        while (scanner.hasNext()) {

            //Create printer object and add to ArrayList
            Transaction transaction = new Transaction();
            pastTransactions.add(transaction);

            //Read the file data with scanner
            String readReceiptData = scanner.nextLine();

            //Separate into String array at ,
            String[] splitList = readReceiptData.split(",");

            //Set printer data elements
            transaction.setOrderNumber(Integer.parseInt(splitList[0]));
            transaction.setItems(splitList[1]);
            transaction.setTransactionPrice(Double.parseDouble(splitList[2]));
            transaction.setPaymentStatus(splitList[3]);
            transaction.setPaymentType(splitList[4]);

        }
        scanner.close();

        //Set Listview to display text when object is clicked
        pTranList.getSelectionModel().selectedItemProperty().addListener((observableValue, s, t1) -> {
            {
                for (Integer i : pTranList.getSelectionModel().getSelectedIndices()) {

                    Transaction transaction = pastTransactions.get(i);
                    transactionsDisplayed.setText(transaction.toString());
                }
            }
        });
    }

    /**
     * Void Check For File Method
     * Checks if a file exists, if not the file is created
     * @param file from inventory
     */
    void checkForFile(File file) {
        boolean result;
        try
        {
            result = file.createNewFile();  //creates a new file
            if(result)      // test if successfully created a new file
            {
                System.out.println("Receipt Log created");
            }
            else
            {
                System.out.println("Receipt Log accessed");
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();    //prints exception if any
        }
    }

    /**
     * FXML Initialize method
     * Calls parseFileData and initializes ArrayList with orderNumber
     * @throws Exception file not found
     */
    @FXML
    public void initialize() throws Exception {
        //Call method to parse file
        parseFileData();

        transactionsDisplayed.setText("Select an Order Number to View");

        //Display device names on listview
        for (Transaction transaction : pastTransactions) {
          pTranList.getItems().add(transaction.getOrderNumber());
        }
    }

    /**
     * FXML button to switch to main menu on click
     */
    @FXML
    private Button menu;

    /**
     *  FXML Return to Menu method
     *  On menu click, get Main Menu scene
     * @throws Exception file not found
     */
    @FXML
    protected void returntoMenu() throws Exception{
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("main-menu.fxml"));
        Stage window = (Stage) menu.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 905, 583));

    }

    /**
     * FXML button to switch to transaction scene on click
     */
    @FXML
    private Button transactions;

    /**
     * FXML Go to Transactions method
     * On transactions click, get Transactions scene
     * @throws Exception file not found
     */
    @FXML
    protected void gotoTransactions() throws Exception{
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("transactions.fxml"));
        Stage window = (Stage) transactions.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 916, 700));

    }
}