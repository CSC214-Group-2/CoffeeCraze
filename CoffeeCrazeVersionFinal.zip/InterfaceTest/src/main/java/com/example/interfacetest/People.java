/**
 * This class represents a person
 * @author Group 2
 * @author Kevin Ung
 * This class is unnecessary in the current version, but could be used to expand functionality in future versions
 */

package com.example.interfacetest;

public class People {

    /**
     * name String variable
     * Stores the person's name
     */
    String name;

    /**
     * dob String variable
     * Stores the person's date of birth
     */
    String dob;

    /**
     * phoneNumber String variable
     * Stores the person's phone number
     */
    String phoneNumber;

    /**
     * email String variable
     * Stores the person's email
     */
    String email;

    /**
     * People constructor with no parameters
     */
    public People() {}

    /**
     * name getter method
     * @return String name
     */
    public String getName(){
        return name;
    }

    /**
     * dob getter method
     * @return String dob
     */
    public String getDob(){
        return dob;
    }

    /**
     * phoneNumber getter method
     * @return String phoneNumber
     */
    public String getPhoneNumber(){
        return phoneNumber;
    }

    /**
     * email getter method
     * @return String email
     */
    public String getEmail(){
        return email;
    }

    /**
     * name setter method
     * @param name String
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * dob setter method
     * @param dob String
     */
    public void setDob(String dob) {
        this.dob = dob;
    }

    /**
     * phoneNumber setter method
     * @param phoneNumber String
     */
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    /**
     * email setter method
     * @param email String
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * toString method to display data elements of People
     * @return String of name, dob, phoneNumber, email
     */
    @Override
    public String toString(){
        return "name: " + name + " dob: " + dob + " phoneNumber: " + phoneNumber + " email: " + email;
    }
}
