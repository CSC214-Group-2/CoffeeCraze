/**
 * This class controls the transaction scene
 * @author Group 2
 * @author Abigail Gaunt
 */

package com.example.interfacetest;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.scene.text.Text;
import java.util.Scanner;
import java.io.*;
import java.io.File;
import java.util.ArrayList;
import java.lang.String;
import javafx.scene.control.Button;

public class TransactionController {

    /**
     * FXML Listview object that takes in String
     */
    @FXML
    private ListView<String> customerOrder;

    /**
     * Array List that stores all items in cart
     */
    static ArrayList<Item> cart = new ArrayList<>();

    /**
     * Array list that stores all drink in current drink inventory
     */
    static ArrayList<String> inventoryDrinks = new ArrayList<>();

    /**
     * Array list that stores all food in current food inventory
     */
    static ArrayList<String> inventoryFoods = new ArrayList<>();

    /**
     * Placeholder drink object to store user's current selection
     */
    Drink coffee = new Drink();

    /**
     * Placeholder food object to store user's current selection
     */
    Food pastry = new Food();

    /**
     * double variable to track order total
     */
    double orderPrice;

    /**
     * boolean variable to check if the customer has paid
     */
    boolean paidOrUnpaid = false;

    /**
     * int variable to store randomly generated order number
     */
    int orderNumber;

    /**
     * String variable to store selected payment type
     */
    String selectedPaymentType;

    /**
     * FXML ComboBox to display if a drink is iced or hot
     */
    @FXML
    private ComboBox<String> CoffeeTempList = new ComboBox<>();

    /**
     * FXML ComboBox to display drink names entered in inventory
     */
    @FXML
    private ComboBox<String> CoffeeTypeList = new ComboBox<>();

    /**
     * FXMl ComboBox to display drink sizes
     */
    @FXML
    private ComboBox<String> CoffeeSizeList = new ComboBox<>();

    /**
     * FXML ComboBox to display food names entered in inventory
     */
    @FXML
    private ComboBox<String> PastryTypeList = new ComboBox<>();

    /**
     * FXML ComboBox to display if food is "for here" or "to go"
     */
    @FXML
    private ComboBox<String> PastryHereOrGoList = new ComboBox<>();

    /**
     * FXML ComboBox to display food spreads
     */
    @FXML
    private ComboBox<String> PastrySpreadList = new ComboBox<>();

    /**
     * FXML ComboBox to display payment types
     */
    @FXML
    private ComboBox<String> PaymentTypeList = new ComboBox<>();

    /**
     * FXML Initialize ComboBoxes method
     * @throws Exception file not found
     * This method initializes the ComboBoxes with values read from the inventory files
     */
    @FXML
    protected void initialize() throws Exception {

        //Read drink inventory file
        File inventoryData = new File("drinkInventory.txt");
        checkForFile(inventoryData);

        Scanner scanner = new Scanner(inventoryData);

        parseInventoryData(scanner, CoffeeTypeList, inventoryDrinks);

        scanner.close();

        //Read food inventory file
        File inventoryData2 = new File("foodInventory.txt");

        checkForFile(inventoryData2);

        Scanner scanner2 = new Scanner(inventoryData2);

        parseInventoryData(scanner2, PastryTypeList, inventoryFoods);

        scanner2.close();

        //Set base price for coffee and pastry
        coffee.setPrice(3.0);
        pastry.setPrice(3.5);

        //Drop down menu items that won't be changeable in inventory
        CoffeeTempList.getItems().add("Hot");
        CoffeeTempList.getItems().add("Iced");

        CoffeeSizeList.getItems().add("Small");
        CoffeeSizeList.getItems().add("Medium");
        CoffeeSizeList.getItems().add("Large");

        PastryHereOrGoList.getItems().add("Here");
        PastryHereOrGoList.getItems().add("To-Go");
        PastrySpreadList.getItems().add("Butter");
        PastrySpreadList.getItems().add("Cream Cheese");
        PastrySpreadList.getItems().add("Chocolate Spread");
        PastrySpreadList.getItems().add("None");

        PaymentTypeList.getItems().add("Credit Card");
        PaymentTypeList.getItems().add("Cash");
        PaymentTypeList.getItems().add("Check");
    }

    /**
     * Void Check For File Method
     * Checks if a file exists, if not the file is created
     * @param file from inventory
     */
    void checkForFile(File file) {
        boolean result;
        try
        {
            result = file.createNewFile();  //creates a new file
            if(result)      // test if successfully created a new file
            {
                System.out.println("Inventory created");
            }
            else
            {
                System.out.println("Inventory accessed");
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();    //prints exception if any
        }
    }

    /**
     * Parse Inventory Data method
     * Reads data from inventory files, saves them in an array list, and displays them in ComboBox
     * @param scanner to read file
     * @param itemType ComboBox
     * @param inventoryItems ArrayList
     */
    void parseInventoryData(Scanner scanner, ComboBox<String> itemType, ArrayList<String> inventoryItems) {
        while (scanner.hasNext()) {

            //Create string object to temporarily store data
            String newItem = new String();

            //read file with the scanner
            String readInventoryData = scanner.nextLine();

            //Separate into String array at ,
            String[] splitList = readInventoryData.split(",");

            //Item found at first index is saved as a drink
            newItem = splitList[0];

            //Add item to array list
            inventoryItems.add(newItem);

            //Add item to ComboBox on interface
            itemType.getItems().add(newItem);

        }
    }

    /**
     * FXML Select Drink Type Method
     * Use CoffeeTypeList ComboBox to select drink type and save it in drink object
     */
    @FXML
    public void onTypeSelect() {
        for (String inventoryDrink : inventoryDrinks) {

            if (CoffeeTypeList.getValue().equals(inventoryDrink)) {

                coffee.setDescription(inventoryDrink);
            }
        }
    }

    /**
     * FXML Select Drink Temp Method
     * Use CoffeeTempList to select temp and save it in drink object
     */
    @FXML
    public void onTempSelect() {

        if (CoffeeTempList.getValue().equals("Iced")) {
            coffee.setTemp("Iced");
        } else {
            coffee.setTemp("Hot");
        }
    }

    /**
     * FXML Select Drink Size Method
     * Use CoffeeSizeList to select size and save it in drink object
     */
    @FXML
    public void onSizeSelect() {
        if (CoffeeSizeList.getValue().equals("Small")) {
            coffee.setSize(1);
        } else if (CoffeeSizeList.getValue().equals("Medium")) {
            coffee.setSize(2);
            coffee.setPrice(3.3);
        } else {
            coffee.setSize(3);
            coffee.setPrice(3.6);
        }
    }

    /**
     * FXML Select Food Type Method
     * Use PastryTypeList to select food type and save it in food object
     */
    @FXML
    public void onPastryTypeSelect() {
        for (String inventoryFood : inventoryFoods) {

            if (PastryTypeList.getValue().equals(inventoryFood)) {

                pastry.setDescription(inventoryFood);
            }
        }
    }

    /**
     * FXML Select Pastry Here or To Go Method
     * Use PastryHereorGoList to select if the food is for here or to go
     */
    @FXML
    public void onPastryHereOrGoSelect() {
        if (PastryHereOrGoList.getValue().equals("Here")) {
            pastry.setHereOrGo("Here");
        }
        else {
            pastry.setHereOrGo("To-Go");
        }
    }

    /**
     * FXML Select Pastry Spread Method
     * Use PastrySpreadList to select a type of spread and save it in food object
     */
    @FXML
    public void onPastrySpreadSelect() {
        if (PastrySpreadList.getValue().equals("Butter")) {
            pastry.setSpreadType("Butter");
        } else if (PastrySpreadList.getValue().equals("Cream Cheese")) {
            pastry.setSpreadType("Cream Cheese");
        } else if (PastrySpreadList.getValue().equals("Chocolate Spread")) {
            pastry.setSpreadType("Chocolate Spread");
        } else {
            pastry.setSpreadType("None");
        }
    }

    /**
     * FXML button to control when a selected drink is added to the order
     */
    @FXML
    private Button addToOrder;

    /**
     * FXML button to control when a selected food is added to the order
     */
    @FXML
    private Button addToOrder2;

    /**
     * FXML Add Drink to Order method
     * When addToOrder is clicked, add the selected drink object to order
     */
    @FXML
    public void addToOrderClick() {
        cart.add(coffee);
        customerOrder.getItems().add(coffee.toString());
        orderPrice += coffee.getPrice();
    }

    /**
     * FXML Add Food to Order method
     * When addToOrder is clicked, add the selected food object to order
     */
    @FXML public void AddToOrder2Click() {
        cart.add(pastry);
        customerOrder.getItems().add(pastry.toString());
        orderPrice += pastry.getPrice();
    }

    /**
     * FXML button to control when an order should be totaled
     */
    @FXML
    private Button completeOrder;

    /**
     * FXML text to display totaled order price
     */
    @FXML
    private Text total;

    /**
     * FXML Complete Order method
     * When completeOrder is clicked, display the orderPrice
     */
    @FXML
    public void onCompleteOrderClick() {

        total.setText(String.valueOf(orderPrice));
    }

    /**
     * FXML Select Payment Type method
     * Use PaymentTypeList to select paymentType and save it in variable
     */
    @FXML
    public void onPaymentTypeSelect() {
        if (PaymentTypeList.getValue().equals("Credit Card")) {
            selectedPaymentType = "Credit Card";
        } else if (PaymentTypeList.getValue().equals("Cash")) {
            selectedPaymentType = "Cash";
        } else if (PaymentTypeList.getValue().equals("Check")){
            selectedPaymentType = "Check";
        } else
        {
            selectedPaymentType = "Not Selected";
        }
    }

    /**
     * FXML TextField to allow cashier to enter customer payment
     */
    @FXML
    private TextField customerPayment;

    /**
     * FXML Text to display if a customer has paid or not
     */
    @FXML
    private Text paymentStatus;

    /**
     * FXML Enter Payment Method
     * Checks if the correct payment has been entered and saves the status
     * Assigns a random order number
     */
    @FXML
    public void onPaymentEntered() {
        Double paymentEntered = Double.valueOf(customerPayment.getText());
        if (paymentEntered == orderPrice) {
            paidOrUnpaid = true;
            paymentStatus.setText("Paid");
            orderNumber = (int)(Math.random() * 1000);
        }
        else {
            paymentStatus.setText("Incorrect Amount");
        }
    }

    /**
     * FXML button to control when transaction is completed
     */
    @FXML
    private Button completeTransaction;

    /**
     * FXML text to display if payment has been accepted
     */
    @FXML
    private Text transactionPassFail;

    /**
     * FXML Complete Transaction Method
     * On completeTransaction click, all transaction data is written to the receipt file
     */
    @FXML
    public void onCompleteTransactionClick() {
        //Format the items from the cart into a String, so it can easily be read from a file
        StringBuilder sb = new StringBuilder();

        for (Item cart : cart) {
            sb.append(cart);
            sb.append(" ");
        }
        String itemString = sb.toString();
        String itemString2 = itemString.replaceAll("\n", " ");
        String itemString3 = itemString2.replaceAll("\t", "");

        //Write all data elements to the file
        try {
            FileWriter myWriter = new FileWriter("receipt.txt", true);
            myWriter.write(orderNumber + "," + itemString3 + "," + orderPrice + " ," + paidOrUnpaid + " ," + selectedPaymentType + "," + "\n");

            myWriter.close();
            transactionPassFail.setText("Ticket Printed. Order Number: " + orderNumber);

        } catch (IOException var3) {
            transactionPassFail.setText("Unable to complete transaction");
            var3.printStackTrace();
        }
    }

    /**
     * FXML button to control when order is cleared
     */
    @FXML
    private Button clearOrder;

    /**
     * FXML Clear Order method
     * When clearOrder is clicked, all items are removed from cart and ListView is emptied
     */
    @FXML
    public void onClearOrderClick() {
        customerOrder.getItems().clear();
        cart.clear();
        orderPrice = 0;
    }

    /**
     * FXML button to control return to main menu
     */
    @FXML
    private Button backToMenu;

    /**
     * FXML Return to Main Menu Method
     * On backToMenu click, gets Main Menu scene
     * @throws Exception file not found
     */
    @FXML
    protected void onBackToMenuClick() throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("main-menu.fxml"));
        Stage window = (Stage) backToMenu.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 905, 583));
    }
}
