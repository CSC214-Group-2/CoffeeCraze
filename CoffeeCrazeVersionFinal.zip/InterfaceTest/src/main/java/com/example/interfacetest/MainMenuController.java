/**
 * This class controls the main menu scene
 * @author Group 2
 * @author Abigail Gaunt
 */

package com.example.interfacetest;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;

public class MainMenuController {


    /**
     * FXML button for transaction screen
     */
    @FXML
    private Button Select1;

    /**
     * FXML button for inventory screen
     */
    @FXML
    private Button Select2;

    /**
     * FXML button for past transaction scene
     */
    @FXML
    private Button Select3;

    /**
     * FXML button for back to log-in screen
     */
    @FXML
    private Button logOut;  //logout

    /**
     * Method for navigation to transaction screen
     * When select button is clicked, gets the transaction scene
     * @throws Exception file not found
     */
    @FXML
    protected void onSelect1ButtonClick() throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("transactions.fxml"));
        Stage window = (Stage) Select1.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 916, 700));
    }

    /**
     * Method for navigation to inventory scene
     * When select button is clicked, gets the inventory scene
     * @throws Exception file not found
     */
    @FXML
    protected void onSelect2ButtonClick() throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("inventory.fxml"));
        Stage window = (Stage) Select2.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 905, 583));
    }

    /**
     * Method for navigation to past transaction scene
     * When select is clicked, gets the past transaction scene
     * @throws Exception file not found
     */
    @FXML
    protected void onSelect3ButtonClick() throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("past_transactions.fxml"));
        Stage window = (Stage) Select3.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 696, 492));
    }

    /**
     * Method for navigation back to log-in scene
     * When log-out is clicked, gets the log-in scene
     * @throws Exception file not found
     */
    @FXML
    protected void onLogOutButtonClick() throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("log-in.fxml"));
        Stage window = (Stage) logOut.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 350, 240));
    }
}