/**
 * This class represents a drink item on the menu
 * @author Group 2
 * @author Kevin Ung
 */

package com.example.interfacetest;

public class Drink extends Item {

    /**
     * Temp String variable
     * Stores if the drink is hot or iced
     */
    String Temp; //Hot or Iced

    /**
     * Size int variable
     * Stores if the drink is small (1), medium (2), or large (3)
     */
    int size;

    /**
     * Drink constructor with no parameters
     */
    public Drink(){}

    /**
     * Temp setter method
     * @param Temp String drink temp
     */
    public void setTemp(String Temp){
        this.Temp = Temp;
    }

    /**
     * Temp getter method
     * @return drink temp
     */
    public String getTemp(){return Temp;}

    /**
     * Size setter method
     * @param size drink size
     */
    public void setSize(int size){
        this.size = size;
    }

    /**
     * Size getter method
     * @return drink size
     */
    public int getSize(){return size;}


    /**
     * toString method to display data elements of Drink
     * @return String of description, temp, size, and price
     */
    @Override
    public String toString(){
        return "Item: " + description +  "\n\tTemp: " + getTemp() + "\n\tSize: " + getSize() + "\n\t\t\tPrice: $" + getPrice();
        }

    }
