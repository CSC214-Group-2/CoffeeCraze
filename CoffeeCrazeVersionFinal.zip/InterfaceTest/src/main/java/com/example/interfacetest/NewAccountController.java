/**
 * This class controls the New Account scene
 * @author Group 2
 * @author Max Mazal
 */

package com.example.interfacetest;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javafx.scene.text.Text;
import javafx.scene.control.TextField;

public class NewAccountController {

    /**
     * FXML button initiates new account information going to file
     */
    @FXML
    private Button Create;

    /**
     * FXML TextField for user to enter name
     */
    @FXML
    private TextField nameTextField;

    /**
     * FXML TextField for user to enter date of birth
     */
    @FXML
    private TextField dobTextField;

    /**
     * FXML TextField for user to enter phone number
     */
    @FXML
    private TextField phoneNumberTextField;

    /**
     * FXML TextField for user to enter email
     */
    @FXML
    private TextField emailTextField;

    /**
     * FXML TextField for user to enter username
     */
    @FXML
    private TextField newUsernameTextField;

    /**
     * FXML TextField for user to enter password
     */
    @FXML
    private TextField newPasswordTextField;

    /**
     * FXML Text to display account creation success
     */
    @FXML
    private Text accountCreated;

    /**
     * String variable to store name from user input
     */
    String name;

    /**
     * String variable to store date of birth
     */
    String dob;

    /**
     * String variable to store phoneNumber
     */
    String phoneNumber;

    /**
     * String variable to store email
     */
    String email;

    /**
     * String variable to store username
     */
    String newUserName;

    /**
     * String variable to store password
     */
    String newPassword;

    /**
     * Void Save to File method
     * Takes a fileName, creates the file, and appends data
     * @param fileName String
     * @param text String
     * @param append boolean
     * @throws IOException file not found
     */
    private static void saveTofile(String fileName, String text, boolean append) throws IOException {
        //creates file
        File file1 = new File(fileName);

        //creates file writer class
        FileWriter fw = new FileWriter(file1,append);

        //creates a print writer class
        PrintWriter pw = new PrintWriter(fw);

        pw.println(text);

        pw.close();
    }

    /**
     * FXML Create New Account method
     * Saves user information from variables and writes it to a file, then displays if creation was successful
     * @throws Exception file not found
     */
    @FXML
    protected void onCreateButtonClick() throws Exception {

        //Get the new account information from the user and save it into variables
        name = nameTextField.getText();
        dob = dobTextField.getText();
        phoneNumber = phoneNumberTextField.getText();
        email = emailTextField.getText();
        newUserName = newUsernameTextField.getText();
        newPassword = newPasswordTextField.getText();

        //Generate a new file and save the new account information and save to the file

        String outputText = newUserName + "|" + newPassword + "|" + name + "|" + dob + "|" + phoneNumber + "|" + email;

        saveTofile("systemLog.txt", outputText,true);

        accountCreated.setText("New account created, please return to log-in.");

    }

    /**
     * FXML button click to return to menu
     */
    @FXML
    private Button returnToLogin;

    /**
     * FXML Return to Login method
     * On returnToLogin click, gets Log-In scene
     * @throws Exception file not found
     */
    @FXML
    protected void onReturnToLoginButtonClick() throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("log-in.fxml"));
        Stage window = (Stage) returnToLogin.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 350, 240));
    }
}
