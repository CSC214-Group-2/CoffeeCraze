/**
 * This class controls the inventory scene
 * @author Group 2
 * @author Abigail Gaunt
 * @author Kevin Ung
 */

package com.example.interfacetest;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class InventoryController {

    /**
     * String variable to store drink name
     */
    String drink;

    /**
     * String variable to store food name
     */
    String food;

    /**
     * FXML TextField to get user drink input
     */
    @FXML
    private TextField enterDrink;

    /**
     * FXML TextField to get user food input
     */
    @FXML
    private TextField enterFood;

    /**
     * FXML ListView to display drink inventory
     */
    @FXML
    private ListView<String> drinkInventoryView;

    /**
     * FXML ListView to display food inventory
     */
    @FXML
    private ListView<String> foodInventoryView;

    /**
     * FXML button to add drink to inventory
     */
    @FXML
    private Button addDrink;

    /**
     * FXML button to add food to inventory
     */
    @FXML
    private Button addFood;

    /**
     * FXML Initialize method
     * Reads current inventory and displays it in Listview
     * @throws Exception file not found
     */
    @FXML
    public void initialize() throws Exception {

        //Read drink inventory list
        File inventoryDrink = new File("drinkInventory.txt");

        checkForFile(inventoryDrink);

    Scanner scanner = new Scanner(inventoryDrink);

        while (scanner.hasNext()) {

            String readInventoryDrink = scanner.nextLine();
            //Separate into String array at ,
            String[] splitList = readInventoryDrink.split(",");

            //Item found at first index is saved as a drink
            drink = splitList[0];

            //Add item to array list
            drinkInventoryView.getItems().add(drink);

        }
        scanner.close();

        //Read food inventory list
        File inventoryFood = new File("foodInventory.txt");

        checkForFile(inventoryFood);

        Scanner scanner2 = new Scanner(inventoryFood);

        while (scanner2.hasNext()) {

            String readInventoryFood = scanner2.nextLine();
            //Separate into String array at ,
            String[] splitList = readInventoryFood.split(",");

            //Item found at first index is saved as food
            food = splitList[0];

            //Add item to array list
            foodInventoryView.getItems().add(food);

        }
        scanner2.close();
    }

    /**
     * FXML Enter Drink method
     * when drink is entered, it saves to a file and is added to ListView
     */
    @FXML
    public void onEnterDrink() {
        try {
            //Write drink to drink inventory file
            drink = enterDrink.getText();
            FileWriter myWriter = new FileWriter("drinkInventory.txt", true);
            myWriter.write(drink + System.lineSeparator());
            enterDrink.clear();
            drinkInventoryView.getItems().add(drink);
            drink = null;
            myWriter.close();

        } catch (IOException var3) {
            System.out.println("Error");
        }
    }

    /**
     * FXML Enter Food
     * when food is entered, it saves to a file and is added to Listview
     */
    @FXML
    public void onEnterFood() {
        try {
            //Write drink to drink inventory file
            food = enterFood.getText();
            FileWriter myWriter = new FileWriter("foodInventory.txt", true);
            myWriter.write(food + System.lineSeparator());
            enterFood.clear();
            foodInventoryView.getItems().add(food);
            food = null;
            myWriter.close();

        } catch (IOException var3) {
            System.out.println("Error");
        }
    }

    /**
     * Void Check For File Method
     * Checks if a file exists, if not the file is created
     * @param file from inventory
     */
    void checkForFile(File file) {
        boolean result;
        try
        {
            result = file.createNewFile();  //creates a new file
            if(result)      // test if successfully created a new file
            {
                System.out.println("Inventory created");
            }
            else
            {
                System.out.println("Inventory accessed");
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();    //prints exception if any
        }
    }

    /**
     * FXML button to go back to main menu
     */
    @FXML
    private Button backToMenu;

    /**
     * FXML Back to Main Menu
     * On backToMenu click, gets main menu scene
     * @throws Exception file not found
     */
    @FXML
    public void onBackToMenuClick () throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("main-menu.fxml"));
        Stage window = (Stage) backToMenu.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 905, 583));
    }
}

