/**
 * This class controls the log-in scene
 * @author Group 2
 * @author Max Mazal
 */

package com.example.interfacetest;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class LogInController {


    /**
     * ArrayList to store cashier object used for login information
     */
    static ArrayList<Cashier> system = new ArrayList<>();

    /**
     * String variable to store username input
     */
    String usrInput;

    /**
     * String variable to store password input
     */
    String pwInput;

    /**
     * FXML button initiates username and password check
     */
    @FXML
    private Button Continue;

    /**
     * FXML TextField for user to type existing username
     */
    @FXML
    private TextField userNameTextField;

    /**
     * FXML TextField for user to type existing password
     */
    @FXML
    private TextField passwordTextField;

    /**
     * FXML Text to display if username/password is incorrect
     */
    @FXML
    private Text loginIncorrect;

    /**
     * FXML Check Log-in method
     * Compares user input with username and password in system log
     * @throws Exception file not found
     */
    @FXML
    protected void onContinueButtonClick() throws Exception {

        addFromFile();

        //Loop through the array list to check for username/password matches

            usrInput = userNameTextField.getText();
            pwInput = passwordTextField.getText();

            for (Cashier system : system) {

                boolean verified = false;

                if((system.username.equals(usrInput)) && (system.password.equals(pwInput))){
                    verified = true;
                }

                //If the username and password match
                if (verified){

                    //Then proceed to main menu scene
                    FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("main-menu.fxml"));
                    Stage window = (Stage) Continue.getScene().getWindow();
                    window.setScene(new Scene(fxmlLoader.load(), 905, 583));
                }
                else{

                    //Clear the TextFields
                    userNameTextField.clear();
                    passwordTextField.clear();

                    //Display that the information entered was incorrect
                    loginIncorrect.setText("Username or Password are incorrect");
                }
            }
    }

    /**
     * FXML button to navigate to new account creation
     */
    @FXML
    private Button newAccount;

    /**
     * FXML To New Account method
     * On newAccount click, gets New Account scene
     * @throws Exception file not found
     */
    @FXML
    protected void onNewUserClick() throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("new_account.fxml"));
        Stage window = (Stage) newAccount.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 625, 375));
    }

    /**
     * Void add From File method
     * Gets data from file and saves it into cashier objects
     */
    private static void addFromFile(){

        //Variables to temporarily hold file data
        String newUserName, newPassword, name, dob, phoneNumber, email;

        //Check for the file. If it is not found, create the file
        File inventoryData = new File("systemLog.txt");

        checkForFile(inventoryData);

        //Create the scanner and get the file data
        Scanner scanner = null;
        try {
            scanner = new Scanner(inventoryData);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        //Parse the data into a cashier object
        while(true){
            assert scanner != null;
            if (!scanner.hasNextLine()) break;
            String readSystem = scanner.nextLine();
            String[] splitList = readSystem.split("\\|");
            newUserName = splitList[0];
            newPassword = splitList[1];
            name = splitList[2];
            dob = splitList[3];
            phoneNumber = splitList[4];
            email = splitList[5];
            Cashier test = new Cashier(newUserName, newPassword, name, dob, phoneNumber, email);
            system.add(test);
        }
    }

    /**
     * Void Check For File Method
     * Checks if a file exists, if not the file is created
     * @param file from inventory
     */
   static void checkForFile(File file) {
        boolean result;
        try
        {
            result = file.createNewFile();  //creates a new file
            if(result)      // test if successfully created a new file
            {
                System.out.println("System Log created");
            }
            else
            {
                System.out.println("System Log accessed");
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();    //prints exception if any
        }
    }
}


