/**
 * This class represents a cashier person, the user of the program
 * @author Group 2
 * @author Kevin Ung
 */

package com.example.interfacetest;

public class Cashier extends People {


    /**
     * String variables
     * Stores username and password
     */
    String username, password;

    /**
     * Cashier Constructor
     * @param username String
     * @param password String
     * @param name String
     * @param dob String
     * @param phoneNumber String
     * @param email String
     */
    public Cashier(String username, String password, String name, String dob, String phoneNumber, String email){

        this.name = name;
        this.dob = dob;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.password = password;
        this.username = username;

    }

    /**
     * Cashier Constructor used for log-in
     * @param username String
     * @param password String
     */
    public Cashier(String username, String password){

        this.password = password;
        this.username = username;
    }

    /**
     * password setter method
     * @param password String
     */
    public void setPassword(String password){
        this.password = password;
    }

    /**
     * username setter method
     * @param username String
     */
    public void setUsername(String username){
        this.username = username;
    }

    /**
     * username getter method
     * @return String username
     */
    public String getUsername(){
        return username;
    }

    /**
     * password getter method
     * @return String password
     */
    public String getPassword() {
        return password;
    }

    /**
     * toString Cashier method
     * @return String of name, dob, phoneNumber, email, username, password
     */
    public String toString(){

        return "Name: " + name + "\nDate of Birth: " + dob + "\nPhone Number" + phoneNumber +
                "\nEmail: " + email   + "\nUsername: " + username +"\nPassword: " + password;

    }
}
