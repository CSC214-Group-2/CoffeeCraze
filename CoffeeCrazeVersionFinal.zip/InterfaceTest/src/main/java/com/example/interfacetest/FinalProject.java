/**
 * Program Name: Coffee Craze
 * Description: A coffee shop billing system that can complete transactions and has a changeable inventory.
 * Class: Computer Science III 401
 * Group: 2
 * Version: 11
 * Last Updated: 11/22/22
 * @author Abigail Gaunt
 * @author Max Mazal
 * @author Kevin Ung
 * @author Jared Rigor
 * @author Rouhid Ayazi
 */

package com.example.interfacetest;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.util.ArrayList;

import java.io.IOException;

public class FinalProject extends Application {

    /**
     * Void Start method
     * Sets the stage and the first scene
     * @param stage Stage
     * @throws IOException file not found
     */
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("log-in.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 350, 240);
        stage.setTitle("Coffee Craze");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Main Function
     * Launches the stage and first scene
     * @param args String
     */
    public static void main(String[] args) {

        launch();
    }
}




