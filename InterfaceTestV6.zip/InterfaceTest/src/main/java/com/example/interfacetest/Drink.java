package com.example.interfacetest;

public class Drink extends Item {

    //Data Elements
    String Temp; //Hot or Iced
    int size; //0 small, 1 medium, 2 large


    //setters and getters
    public String getTemp(){return Temp;}
    public String setTemp(String Temp){return this.Temp = Temp;}
    public void setSize(int size){
        this.size = size;
    }
    public int getSize(){return size;}


    //object constructor
    public Drink(){};

    public Drink(double price, String description, int stockQty, boolean cold, int qtySel, boolean selected, boolean ice, int size){
        super(price, description, stockQty, cold, qtySel, selected);

        this.cold = cold;
        this.size = size;
    }


    @Override
    public String toString(){
        return "Item: " + description +  "\n\tTemp: " + getTemp() + "\n\tSize: " + getSize() + "\n\t\t\tPrice: $" + getPrice();
        }

    }
