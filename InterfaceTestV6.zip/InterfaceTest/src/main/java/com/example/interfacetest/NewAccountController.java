package com.example.interfacetest;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.event.ActionEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javafx.scene.text.Text;

import javafx.scene.control.TextField;

public class NewAccountController {

    //Creates new text file corresponding to new cashier object
    @FXML
    void printTicket(ActionEvent event) {
       //System.out.println(Seat.seatNumber);
        //System.out.println(ReservationController.booking);

        try {
        FileWriter myWriter = new FileWriter("newCashier.txt");
        myWriter.write("Hello");
        myWriter.close();
        System.out.println("Printed");
    } catch (IOException var3) {
        System.out.println("An error occurred.");
        var3.printStackTrace();
    }

}

    //registers cashier using usr input and password input
    public void cashierReg(String newUsr, String newPass){
        Cashier regCashier = new Cashier(newUsr, newPass);
        // system.add(regCashier);
    }


    //Nodes on Scenebuilder to get user input for new account
    @FXML
    private Button Create;
    @FXML
    private TextField nameTextField;
    @FXML
    private TextField dobTextField;
    @FXML
    private TextField phoneNumberTextField;
    @FXML
    private TextField emailTextField;
    @FXML
    private TextField newUsernameTextField;
    @FXML
    private TextField newPasswordTextField;
    @FXML
    private Text accountCreated;

    //Variables to store user information taken from text fields
    String name;
    String dob;
    String phoneNumber;
    String email;
    String newUserName;
    String newPassword;
    int IDNumber;



    //saveTofile("systemLog.txt", outputText, true);

    private static void saveTofile(String fileName, String text, boolean append) throws IOException {
        //creates file
        File file1 = new File(fileName);

        //creates file writer class
        FileWriter fw = new FileWriter(file1,append);

        //creates a print writer class
        PrintWriter pw = new PrintWriter(fw);

        pw.println(text);

        pw.close();
    }


    @FXML
    protected void onCreateButtonClick() throws Exception {

        //Get the new account information from the user and save it into variables
        name = nameTextField.getText();
        dob = dobTextField.getText();
        phoneNumber = phoneNumberTextField.getText();
        email = emailTextField.getText();
        newUserName = newPasswordTextField.getText();
        newPassword = newPasswordTextField.getText();

        //Generate ID Number using math.random()

        //Generate a new file and save the new account information and save to the file

        String outputText = name + "|" + dob + "|" + phoneNumber + "|" + email + "|" + newUserName + "|" + newPassword;

        saveTofile("systemLog.txt", outputText,true);

        accountCreated.setText("New account created, please return to log-in.");

        /*
        //Return to the log-in screen
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("log_in.fxml"));
        Stage window = (Stage) Create.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 905, 583));

         */
    }

    //Navigates back to log-in without creating any cashier objects
    @FXML
    private Button returnToLogin;

    @FXML
    protected void onReturnToLoginButtonClick() throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("log-in.fxml"));
        Stage window = (Stage) returnToLogin.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 350, 240));
    }
}
