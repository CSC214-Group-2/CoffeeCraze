package com.example.interfacetest;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class InventoryController {

    static ArrayList<Item> inventory = new ArrayList<Item>(); //inventory of items, supposed to go into controller

    @FXML
    public void excelWriter() throws Exception {
        try {
            FileWriter myWriter = new FileWriter("Inventory.txt");

            myWriter.write("Hello World");
            myWriter.close();

        } catch (IOException var3) {
            var3.printStackTrace();
        }

    }
    @FXML
    private Button backToMenu;

}