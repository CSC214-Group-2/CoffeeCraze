module com.example.interfacetest {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.interfacetest to javafx.fxml;
    exports com.example.interfacetest;
}