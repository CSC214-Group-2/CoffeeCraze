/**
 * This class represents a food item on the menu
 * @author Group 2
 */

package com.example.interfacetest;

public class Food extends Item {

    /**
     * HereOrGo String variable
     * Stores if the food item is for here or to go
     */
    private String hereOrGo;

    /**
     * SpreadType String variable
     * Stores types of spreads to go with food item
     */
    private String spreadType;

    /**
     * Food constructor with no parameters
     */
    public Food(){}

    /**
     * hereOrGo setter method
     * @param hereOrGo String "for here" or "to go"
     */
    public void setHereOrGo(String hereOrGo){this.hereOrGo = hereOrGo;}

    /**
     * hereOrGo getter method
     * @return String "for here" or "to go"
     */
    public String getHereOrGo(){return hereOrGo;}

    /**
     * spreadType setter method
     * @param spreadType String type of spread for food
     */

    public void setSpreadType(String spreadType){this.spreadType = spreadType;}

    /**
     * spreadType getter method
     * @return String type of spread for food
     */
    public String getSpreadType(){return spreadType;}

    /**
     * toString method to display data elements of Food
     * @return String of description, hereOrGo, and spreadType
     */
    public String toString(){
        return "Item: " + description + "\n\t" + getHereOrGo() + "\n\tSpread: " + getSpreadType() + "\n\t\t\tPrice: $" + getPrice();
    }
}
