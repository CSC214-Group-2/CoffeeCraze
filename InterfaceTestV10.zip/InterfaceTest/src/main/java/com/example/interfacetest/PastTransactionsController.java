package com.example.interfacetest;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class PastTransactionsController {

///*

    //is the design going to be a scrollable listview with dates of past transactions and clicking on a
    //date pulls up the past transactions on another listview? if so:

    //list of past transactions, should only show dates on listview
    ArrayList<Transaction> pastTransactions = new ArrayList();
    @FXML
    private ListView<Integer> pTranList; //should be connected to pastTransactions

    //shows entire list of selected transaction
    @FXML
    private ListView<String> pTranListExpanded;

    @FXML
    private Text transactionsDisplayed;

    //button press pulls up selected transaction on the showcase listview

    //Method to parse file, store data elements and add listener
    public void parseFileData() throws Exception {

        File printerData = new File("receipt.txt");
        boolean result;
        try
        {
            result = printerData.createNewFile();  //creates a new file
            if(result)      // test if successfully created a new file
            {
                System.out.println("Receipt file created");
            }
            else
            {
                System.out.println("Receipt file already exists");
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();    //prints exception if any
        }

        Scanner scanner = new Scanner(printerData);

        //Loop through file
        while (scanner.hasNext()) {

            //Create printer object and add to ArrayList
            Transaction transaction = new Transaction();
            pastTransactions.add(transaction);

            //Read the file data with scanner
            String readPrinterData = scanner.nextLine();

            //Separate into String array at ,
            String[] splitList = readPrinterData.split(",");
            System.out.println(splitList[3]);

            //Set printer data elements
            transaction.setOrderNumber(Integer.parseInt(splitList[0]));
            transaction.setItems(splitList[1]);
            transaction.setTransactionPrice(Double.parseDouble(splitList[2]));
            transaction.setPaymentStatus(splitList[3]);
            transaction.setPaymentType(splitList[4]);

        }
        //Set Listview to display text when object is clicked
        pTranList.getSelectionModel().selectedItemProperty().addListener((observableValue, s, t1) -> {
            {
                for (Integer i : pTranList.getSelectionModel().getSelectedIndices()) {

                    Transaction transaction = pastTransactions.get(i);
                    transactionsDisplayed.setText(transaction.toString());
                }
            }
        });
    }

    @FXML
    public void initialize() throws Exception {
        //Call method to parse file
        parseFileData();

        transactionsDisplayed.setText("Select an Order Number to View");

        //Display device names on listview
        for (Transaction transaction : pastTransactions) {
          pTranList.getItems().add(transaction.getOrderNumber());
        }
    }

    //button press action that should return to main menu
    @FXML
    private Button menu;
    //this should switch scenes into past_transactions
    @FXML
    protected void returntoMenu(ActionEvent event) throws Exception{
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("main-menu.fxml"));
        Stage window = (Stage) menu.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 905, 583));

    }

    //button press action that should go to transactions
    @FXML
    private Button transactions;
    //this should switch scenes into past_transactions
    @FXML
    protected void gotoTransactions(ActionEvent event) throws Exception{
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("transactions.fxml"));
        Stage window = (Stage) menu.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 905, 583));

    }
}