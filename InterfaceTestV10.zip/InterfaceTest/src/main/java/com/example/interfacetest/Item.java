/**
 * This class represents an item on the menu
 * @author Group 2
 */

package com.example.interfacetest;

public class Item{

    /**
     * Price double variable
     * Stores the price of an item
     */
    double price;

    /**
     * Description String variable
     * Stores the name/description of an item
     */
    String description; // description of the product

    /**
     * Item constructor with no parameters
     */
    public Item(){}

    /**
     * Price setter method
     * @param price double
     */
    public void setPrice(double price) {this.price = price;}

    /**
     * Price setter method
     * @return double price
     */
    public double getPrice() {
        return price;
    }

    /**
     * description setter method
     * @param description String
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * description getter method
     * @return String description
     */
    public String getDescription() {
        return description;
    }

    /**
     * toString method to display data elements of Item
     * @return String of price, description
     */
    @Override
    public String toString(){
        return "Price: $"+ price + "\n   Description:" + description + "\n ";
    }
}
