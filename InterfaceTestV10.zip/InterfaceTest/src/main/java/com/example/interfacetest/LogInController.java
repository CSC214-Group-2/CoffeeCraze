/*
Log-In Controller:
Controls the log-in scene that allows a user to enter account information. If their information
is found in the system log, they can enter the rest of the program.
 */

package com.example.interfacetest;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class LogInController {

    //This is a test cashier object
    Cashier testCashier = new Cashier("Ken Ding", "01/01/01", "222-222-2222", "email@email.com", "KenDing1111", "password");


    //Array List
    static ArrayList<Cashier> system = new ArrayList<>(); //stores people (used for login information)

    //stores input for username and password from text fields
    String usrInput;
    String pwInput;

    @FXML
    private Button Continue;                    //Initiates username and password check
    @FXML
    private TextField userNameTextField;        //User types already created username
    @FXML
    private TextField passwordTextField;        //User types already created password

    @FXML
    private Text loginIncorrect;                //Displays when username/password is incorrect

    @FXML
    protected void onContinueButtonClick() throws Exception {

        //Get user input and store in string variables
        system.add(testCashier);

        addFromFile();

        //Loop through the array list to check for username/password matches

            usrInput = userNameTextField.getText();
            pwInput = passwordTextField.getText();

            for (Cashier system : system) {

                boolean verified = false;

                if((system.username.equals(usrInput)) && (system.password.equals(pwInput))){
                    verified = true;
                }

                //If the username and password match
                if (verified){

                    //Then proceed to main menu scene
                    FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("main-menu.fxml"));
                    Stage window = (Stage) Continue.getScene().getWindow();
                    window.setScene(new Scene(fxmlLoader.load(), 905, 583));
                }
                else{

                    //Clear the TextFields
                    userNameTextField.clear();
                    passwordTextField.clear();

                    //Display that the information entered was incorrect
                    loginIncorrect.setText("Username or Password are incorrect");
                }
            }
    }

    @FXML
    private Button newAccount;      //Button for New Account scene

    //When the new account button is clicked, go to the new account scene
    @FXML
    protected void onNewUserClick() throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("new_account.fxml"));
        Stage window = (Stage) newAccount.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 625, 375));
    }

    //Reads the file data saved in the system log, parses it, then adds it to the cashier array list
    private static void addFromFile(){

        //Variables to temporarily hold file data
        String newUserName, newPassword, name, dob, phoneNumber, email;

        //Check for the file. If it is not found, create the file
        File inventoryData = new File("systemLog.txt");
        boolean result;
        try
        {
            result = inventoryData.createNewFile();  //creates a new file
            if(result)                          // test if successfully created a new file
            {
                System.out.println("System Log created");
            }
            else
            {
                System.out.println("System log already exists");
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();    //prints exception if any
        }

        //Create the scanner and get the file data
        Scanner scanner = null;
        try {
            scanner = new Scanner(inventoryData);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        //Parse the data into a cashier object
        while(scanner.hasNextLine()){
            String readSystem = scanner.nextLine();
            String[] splitList = readSystem.split("\\|");
            newUserName = splitList[0];
            newPassword = splitList[1];
            name = splitList[2];
            dob = splitList[3];
            phoneNumber = splitList[4];
            email = splitList[5];
            Cashier test = new Cashier(newUserName, newPassword, name, dob, phoneNumber, email);
            system.add(test);
        }
    }
}


