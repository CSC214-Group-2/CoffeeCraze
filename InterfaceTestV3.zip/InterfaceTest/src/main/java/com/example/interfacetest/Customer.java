package com.example.interfacetest;

public class Customer extends People {

    String address;
    boolean membership;

    //setters getters
    public String getAddress() {
        return address;
    }

    public boolean getMembership() {
        return membership;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setMembership(boolean membership) {
        this.membership = membership;
    }

    //No arg constructor?
    public Customer() {

    }

    //object constructor
    public Customer(String name, String dob, String phoneNumber, String email, String address, boolean
            membership) {

        this.name = name;
        this.dob = dob;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.address = address;
        this.membership = membership;

    }

    //override
    @Override
    public String toString() {

        return "Name: " + name + "\nDate of Birth: " + dob + "\nPhone Number" + phoneNumber +
                "\nEmail: " + email + "\nAddress: " + address + "\nMembership: " + membership;


    }
}
