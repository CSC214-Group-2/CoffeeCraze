package com.example.interfacetest;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.scene.control.Button;

import java.util.ArrayList;

public class MainMenuController {


    //Buttons for menu selection
    @FXML
    private Button Select1; //transaction
    @FXML
    private Button Select2; //inventory
    @FXML
    private Button Select3; //past transaction
    @FXML
    private Button logOut;  //logout

    //To transactions screen on click
    @FXML
    protected void onSelect1ButtonClick() throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("transactions.fxml"));
        Stage window = (Stage) Select1.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 905, 583));
    }

    //To inventory screen on click
    @FXML
    protected void onSelect2ButtonClick() throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("inventory.fxml"));
        Stage window = (Stage) Select2.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 905, 583));
    }

    //To past transactions screen on click
    @FXML
    protected void onSelect3ButtonClick() throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("past_transactions.fxml"));
        Stage window = (Stage) Select3.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 905, 583));
    }

    //Back to Log-in screen click
    @FXML
    protected void onLogOutButtonClick() throws Exception {
        FXMLLoader fxmlLoader = new FXMLLoader(FinalProject.class.getResource("log-in.fxml"));
        Stage window = (Stage) Select3.getScene().getWindow();
        window.setScene(new Scene(fxmlLoader.load(), 350, 240));
    }

}